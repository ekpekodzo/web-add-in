import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule],
  template: `<h1>Bienvenue dans Angular 19 standalone !</h1>`,
})
export class AppComponent {}